module.exports = {
  teamsWebhookUrl: process.env.TEAMS_WEBHOOK_URL
}
